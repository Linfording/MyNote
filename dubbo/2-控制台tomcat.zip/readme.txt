1)war部署到tomcat
2)修改WEB-INF/dubbo.properties,修改zk的访问地址

dubbo.registry.address=zookeeper://192.168.233.25:2181?backup=192.168.233.26:2181,192.168.233.27:2181

dubbo://				dubbo协议头
10.8.42.228：20880		虚拟ip:注册端口
/com.jt.